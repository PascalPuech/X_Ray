function saveF
global x y data vt
datas=data;xs=x;ys=y;
ip=find(data.fname=='.');
nom=[data.fname(1:ip-1),'_bg',data.fname(ip:end)];
nom = fullfile(data.pname, nom);
mat=[x,y];
save(nom,'-ascii','-tabs','mat')
nom=get(data.nom,'String');
[x,y]=lectura(nom);
mat=[x,y];
removebackgroundS;
mat=[mat,y];         
ip=find(data.fname=='.');
nom=[data.fname(1:ip-1),'_fit',data.fname(ip:end)];
nom = fullfile(data.pname, nom);
pf=fopen(nom,'w');
n=size(mat,1);
for i=1:n
    fprintf(pf,'%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3));
end
fclose(pf);
% Lc
if data.z002==true
    %save partie 002
    mat=data.z002mat;
    ip=find(data.fname=='.');
    nom=[data.fname(1:ip-1),'_fitLc',data.fname(ip:end)];
    nom = fullfile(data.pname, nom);
    pf=fopen(nom,'w');
    fprintf(pf,'#parameter : Lc(A)=%f  c(A)=%f\r\n',str2num(get(data.zLc,'String')),str2num(get(data.zc,'String')));
    n=size(mat,1);
    for i=1:n
        fprintf(pf,'%f\t%f\r\n',mat(i,1),mat(i,2));
    end
    fclose(pf);
end
   
%La10
if data.z10==true
    %save partie 10
    mat=data.z10mat;
    ip=find(data.fname=='.');
    nom=[data.fname(1:ip-1),'_fitLa10',data.fname(ip:end)];
    nom = fullfile(data.pname, nom);
    pf=fopen(nom,'w');
    fprintf(pf,'#parameter : La(A)=%f  a(A)=%f\r\n',str2num(get(data.zLa10,'String')),str2num(get(data.za10,'String')));
    if vt(3)==1
        Lpcb=str2num(get(data.zLpcb,'String'));
        fprintf(pf,'#parameter : Lc bernal(A)=%f\r\n',Lpcb);
    end
    if vt(4)==1
        Lpcr=str2num(get(data.zLpcr,'String'));
        fprintf(pf,'#parameter : Lc Rhombo(A)=%f\r\n',Lpcb);
    end
    n=size(mat,1);m=size(mat,2);
    for i=1:n
        switch m
            case 2
                fprintf(pf,'%f\t%f\r\n',mat(i,1),mat(i,2));
            case 3
                fprintf(pf,'%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3));
            case 4
                fprintf(pf,'%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4));
            case 5
                fprintf(pf,'%f\t%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4),mat(i,5));
            case 6
                fprintf(pf,'%f\t%f\t%f\t%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4),mat(i,5),mat(i,6));
        end
    end
    fclose(pf);
end

%La11
if data.z11==true
    %save partie 11
    mat=data.z11mat;
    ip=find(data.fname=='.');
    nom=[data.fname(1:ip-1),'_fitLa11',data.fname(ip:end)];
    nom = fullfile(data.pname, nom);
    pf=fopen(nom,'w');
    fprintf(pf,'#parameter : La(A)=%f  a(A)=%f\r\n',str2num(get(data.zLa11,'String')),str2num(get(data.za11,'String')));
    if vt(3)==1
        Lpcb=str2num(get(data.zLpcb,'String'));
        fprintf(pf,'#parameter : Lc bernal(A)=%f\r\n',Lpcb);
    end
    if vt(4)==1
        Lpcr=str2num(get(data.zLpcr,'String'));
        fprintf(pf,'#parameter : Lc Rhombo(A)=%f\r\n',Lpcb);
    end
    n=size(mat,1);m=size(mat,2);
    for i=1:n
        switch m
            case 2
                fprintf(pf,'%f\t%f\r\n',mat(i,1),mat(i,2));
            case 3
                fprintf(pf,'%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3));
            case 4
                fprintf(pf,'%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4));
            case 5
                fprintf(pf,'%f\t%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4),mat(i,5));
            case 6
                fprintf(pf,'%f\t%f\t%f\t%f\t%f\t%f\t%f\r\n',mat(i,1),mat(i,2),mat(i,3),mat(i,4),mat(i,5),mat(i,6));
        end      
    end
    fclose(pf);
end
data=datas;x=xs;ys=y;



