function [y] = fctbernal11s(La,Lc,x,dec11)
%ici param n'est pas affect�, � mettre sur une variable ...
param=[ 7783.35-18.32-0.693      -291.87      -2168.37       5383.17       5392.82        -28.33         25.24  ...
    -124.61        107.71        247.22        180.71    95.13]/100;
Lc=min(max([10.5 Lc]),1000);
wm=param(1)+(param(2)./La).*(1+param(3)./Lc)+dec11;
Gd=param(4)./La.*(1+param(10)./Lc);
Gg=(param(5)./La).*(1+param(6)./Lc);
nd=1;
ng=1;
cte=param(9)+param(11)./La;
intensite=La*param(7)*(1+param(8)./Lc)*(1+param(12)./La);

ng=min(max(0,abs(ng)),1);
nd=min(max(0,abs(nd)),1);

y=(x<wm).*((abs(ng)*exp(-log(2)*((x-wm)/Gg).^2)+(1-abs(ng))*1./(1+((x-wm)/Gg).^2)));
y=y+(x>=wm).*((abs(nd)*exp(-log(2)*((x-wm)/Gd).^2)+(1-abs(nd))*1./(1+((x-wm)/Gd).^2)));
y=abs(intensite)*y+cte;

end