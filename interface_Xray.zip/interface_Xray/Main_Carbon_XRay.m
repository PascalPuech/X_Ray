function Main_Carbon_XRay(Action)
global x y data vt
switch nargin
    case 0, initialise
    case 1
        fig=gcf;
        switch Action
            case 'Close', delete(gcf)
            case 'readM'
                readfile;
            case 'rmbg'
                 removebackground;
                 data.yrmbg=y;
            case 'reset'
                [x,y]=lectura(data.nom);
                set(data.hxy,'XData',x);
                set(data.hxy,'YData',y);
            case 'erase'
                xfrom=str2num(get(data.xfrom,'String'));
                xto=str2num(get(data.xto,'String'));
                if isnumeric(xfrom)&&isnumeric(xto)&&(xfrom<xto)
                    ind=find((x>xfrom).*(x<xto));
                    x(ind)=[];y(ind)=[];
                    set(data.hxy,'XData',x);
                    set(data.hxy,'YData',y);
                end
                hold on
            case 'z002'   
                data.z002=true;
                fctLc              
            case 'z10'
                data.z10=true;
                data.c10=data.c10+1;
                fctLa10
            case 'z11' 
                data.z11=true;
                data.c11=data.c11+1;
                fctLa11 
            case 'soustrait'
                ymoins=str2num(get(data.moins,'String'));
                y=y-ymoins;
                set(data.hxy,'YData',y);
            case 'reload'
                readfileagain;
            case 'saveF'
                saveF
            otherwise
                error('error');
        end
    otherwise
        error('still error');
end

