function err=fctz11(param)
global xk yk vt
%param=[0,ym,La,0,Lpcb,Lpcr, vtv(1:4)];
yf=zeros(size(yk));
param(7:10)=abs(vt.*param(7:10))/sum(abs(vt.*param(7:10)));
if vt(1)==1
    yf=yf+param(7)*fctturbo11s(xk,param(3),param(4));
end
if vt(2)==1
    yf=yf+param(8)*fctABfano11s(param(3),param(4),xk);
end
if vt(3)==1
    yf=yf+param(9)*fctbernal11s(param(3),param(5),xk,param(4));
end
if vt(4)==1
    yf=yf+param(10)*fabc11s(param(3),param(6),xk,param(4));
end
yf=param(2)*yf+param(1);
err=sqrt(sum((yk-yf).^2));
end

