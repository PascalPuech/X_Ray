function fctLc
global x y data xk yk
ind=find((x<33).*(x>20));
xk=x(ind);yk=y(ind);[ym,im]=max(yk);
option=optimset('MaxFunEvals',100000,'MaxIter',100000,'TolX',1.e-8);
ind=find(yk>ym/2);
fw=xk(ind(end))-xk(ind(1));
param=[0  ym fw 0.5 xk(im)];
parama=fminsearch(@fctvp,param,option);
yf=parama(1)+voigt(xk,parama(2:end));
if exist('data.h002')==1
    set(data.h002,'Ydata',yf)
else
    hold on
    h002=plot(xk,yf);
    data.h002=h002;
    hold off
end
mat=[xk,yk,yf];
data.z002mat=mat;
%Lc correction for small Lc
%Lcrel=alpLc*Lcapp
Lc=0.89*1.5418/(parama(3)*2/180*pi*cos(parama(5)/2*pi/180));
alpLc=1./(1.08+(Lc<20).*(-0.45+0.0225*Lc));
Lc=Lc*alpLc;
%creel=alp*capp
c=1.5418/(2*sin(parama(5)/2*pi/180));
La=str2num(get(data.zLa10,'String'));
if (La>1).*(La<500)
    alp=1+((-0.1997+15.36./La-150.6./La.^2)./Lc+(1.560-297.2./La+3527./La.^2)./Lc.^2+(-30.69+981.2./La-9352./La.^2)./Lc.^3);
    c=c*alp;
end
set(data.zLc,'String',num2str(Lc));
set(data.zc,'String',num2str(c));
end

