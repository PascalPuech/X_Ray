function initialise
global x y data
close all
fig=figure('CloseRequestFcn','Main_Carbon_XRay Close');
set(fig,'Position',[200 200 1000 800])
h=subplot(1,1,1);
set(h,'Position',[0.1 0.35 0.8 0.6])
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.10,0.23,0.08,0.07],'String','Read','Callback','Main_Carbon_XRay readM');
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.20,0.23,0.08,0.07],'String','Remove bg','Callback','Main_Carbon_XRay rmbg');
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.30,0.23,0.08,0.07],'String','Save','Callback','Main_Carbon_XRay saveF');
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.40,0.23,0.08,0.07],'String','Cancel','Callback','Main_Carbon_XRay reset');
xfrom = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.50,0.23,0.1,0.05],'String','from');data.xfrom=xfrom;
xto = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.60,0.23,0.1,0.05],'String','to');data.xto=xto;
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.70,0.23,0.08,0.07],'String','Suppr','Callback','Main_Carbon_XRay erase');

turbo = uicontrol( fig , 'style' , 'Radio' , 'Units','normalized','Position',[0.6,0.15,0.065,0.03], 'String' , 'Turbo', 'Value', 1);data.turbo=turbo;
xturbo = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.70,0.15,0.1,0.03],'String','%');data.xturbo=xturbo;
pair = uicontrol( fig , 'style' , 'Radio' , 'Units','normalized','Position',[0.6,0.12,0.065,0.03], 'String' , 'Pair', 'Value', 0);data.pair=pair;
xpair = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.70,0.12,0.1,0.03],'String','%');data.xpair=xpair;
bernal = uicontrol( fig , 'style' , 'Radio' , 'Units','normalized','Position',[0.6,0.09,0.065,0.03], 'String' , 'Bernal', 'Value', 0);data.bernal=bernal;
xbernal = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.70,0.09,0.1,0.03],'String','%');data.xbernal=xbernal;
uicontrol(fig,'Style','text','Units','normalized','Position',[0.80,0.085,0.05,0.03],'String','L''c(A)=');
zLpcb = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.85,0.09,0.1,0.03],'String','to be calculated');data.zLpcb=zLpcb;
rhombo = uicontrol( fig , 'style' , 'Radio' , 'Units','normalized','Position',[0.6,0.06,0.065,0.03], 'String' , 'Rhombo', 'Value', 0);data.rhombo=rhombo;
xrhombo = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.70,0.06,0.1,0.03],'String','%');data.xrhombo=xrhombo;
uicontrol(fig,'Style','text','Units','normalized','Position',[0.80,0.055,0.05,0.03],'String','L''c(A)=');
zLpcr = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.85,0.06,0.1,0.03],'String','to be calculated');data.zLpcr=zLpcr;

uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.1,0.15,0.10,0.04], 'String' , '20-33','Callback','Main_Carbon_XRay z002');
uicontrol(fig,'Style','text','Units','normalized','Position',[0.225,0.14,0.05,0.04],'String','Lc(A)=');
zLc = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.27,0.15,0.1,0.04],'String','to be calculated');data.zLc=zLc;
uicontrol(fig,'Style','text','Units','normalized','Position',[0.425,0.14,0.05,0.04],'String','c(A)=');
zc = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.47,0.15,0.1,0.04],'String','to be calculated');data.zc=zc;
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.1,0.10,0.10,0.04], 'String' , '35-70','Callback','Main_Carbon_XRay z10');
uicontrol(fig,'Style','text','Units','normalized','Position',[0.225,0.09,0.05,0.04],'String','La(A)=');
zLa10 = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.27,0.1,0.1,0.04],'String','to be calculated');data.zLa10=zLa10;
uicontrol(fig,'Style','text','Units','normalized','Position',[0.425,0.09,0.05,0.04],'String','a(A)=');
za10 = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.47,0.1,0.1,0.04],'String','to be calculated');data.za10=za10;
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.1,0.05,0.10,0.04], 'String' , '70-85','Callback','Main_Carbon_XRay z11');
uicontrol(fig,'Style','text','Units','normalized','Position',[0.225,0.04,0.05,0.04],'String','La(A)=');
zLa11 = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.27,0.05,0.1,0.04],'String','to be calculated');data.zLa11=zLa11;
uicontrol(fig,'Style','text','Units','normalized','Position',[0.425,0.04,0.05,0.04],'String','a(A)=');
za11 = uicontrol(fig,'Style','edit','Units','normalized','Position',[0.47,0.05,0.1,0.04],'String','to be calculated');data.za11=za11;

uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.9,0.20,0.05,0.04], 'String' , '-','Callback','Main_Carbon_XRay soustrait');
moins=uicontrol(fig,'Style','edit','Units','normalized','Position',[0.9,0.15,0.05,0.04],'String','0.0');data.moins=moins;
nom=uicontrol(fig,'Style','edit','Units','normalized','Position',[0.1,0.96,0.65,0.04],'String','nom');data.nom=nom;
uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[0.9,0.96,0.05,0.04], 'String' , 'Reload','Callback','Main_Carbon_XRay reload');

data.z002=false;
data.fig=fig;
data.c10=0;
data.c11=0;
data.z10=false;
data.z11=false;


