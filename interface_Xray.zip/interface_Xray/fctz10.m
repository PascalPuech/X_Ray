function err=fctz10(param)
global xk yk vt
%param=[0,ym,La,0,Lpcb,Lpcr, vtv(1:4)];
yf=zeros(size(yk));
param(7:10)=abs(vt.*param(7:10))/sum(abs(vt.*param(7:10)));
if vt(1)==1
    yf=yf+param(7)*fctturbo10s(xk,param(3),param(4));
end
if vt(2)==1
    yf=yf+param(8)*fctABfano10s(param(3),param(4),xk);
end
if vt(3)==1
    yf=yf+param(9)*fctbernal10s(param(3),param(5),param(4),param(4),xk);
end
if vt(4)==1
    yf=yf+param(10)*fabc10s(param(3),param(6),param(4),param(4),xk);
end
yf=param(2)*yf+param(1);
err=sqrt(sum((yk-yf).^2));
end

