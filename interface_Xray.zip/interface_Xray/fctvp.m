function err=fctvp(parama)
global xk yk 
yf=parama(1)+voigt(xk,parama(2:end));
err=sqrt(sum((yk-yf).^2));

