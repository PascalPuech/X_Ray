clear all, close all, clc
h=subplot(1,2,1);
set(h,'Position',[0.1 0.1 0.2 0.8])
[x,y]=lectura('2000_fit.txt');
plot(x,y(:,2))
xlim([24.5 30.5])
ylabel('X-Ray Intensity (arb. u.)')
xlabel('2\theta (°)')
hold on
[x,y]=lectura('2000_fitLc.txt');
plot(x,y,'r--')
set(h,'YTick',[])
set(h,'FontSize',10)
text(26.5,1000000,'Lc=19.0nm')

hh=subplot(1,2,2);
set(hh,'Position',[0.4 0.1 0.5 0.8])
[x,y]=lectura('2000_fit.txt');
plot(x,y(:,2))
xlim([35 80])
xlabel('2\theta (°)')
hold on
[x,y]=lectura('2000_fitLa11.txt');
h=plot(x,y);set(h(1),'Color','r');set(h(2),'Color','c');set(h(3),'Color','m')
[x,y]=lectura('2000_fitLa10.txt');
h=plot(x,y);set(h(1),'Color','r');set(h(2),'Color','c');set(h(3),'Color','m')
ylim([0 45000])
set(hh,'YTick',[])
text(60,35000,{'T=2000°C';[];'80% Turbostratic';'20% Pair';'La_{10}=15.2nm';'La_{11}=15.8nm'})
