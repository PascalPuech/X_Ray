clear all, close all, clc
global x y xk yk ind n
n=5;
co='mb';
for i=1:2
    switch i
        case 1
            nom='cellulose_1800�c_2�cmin.txt';
%         case 2
%             nom='cellulose_1000�c_8�cmin.txt';
        case 2
            nom='cellulose_1000�c_2�cmin.txt';
%         case 4
%             nom='cellulose_1800�c_8�cmin.txt';
    end
    [x,y]=lectura(nom);
    option=optimset('MaxFunEvals',100000,'MaxIter',100000,'TolX',1.e-8);
        c=fminsearch(@fctal,[1.13       1366.10        240.85      31036.69         30.80      25360.05   30.80      20360.05 0.33],option);
        q=sin(x/360*pi);
        yf=zeros(size(x));
        for ii=1:2:n
            yf=yf+abs(c(ii+1))*exp(-c(ii)*q.^2);
        end
        yf=yf+c(end);
        

    y=(y-yf);%.*(x<70)+y.*(x>=70);
    
    
    ind=find((x<30).*(x>20));h=max(y(ind))-min(y(ind));y=y/h;
    plot(x,y+i,co(i))
    hold on

% 
%     peak at 2theta=12
    ind=find((x<16).*(x>5));xk=x(ind);yk=y(ind);[ym,im]=max(yk);
    param=[0  ym 1 0.5 xk(im)];
    parama=fminsearch(@fctvp,param,option);
    yf=parama(1)+voigt(xk,parama(2:end));
    disp(['HW=',num2str(parama(3)) ,'Lunknow=',num2str(0.89*1.5418/(parama(3)*2/180*pi*cos(parama(5)/2*pi/180))),'  unknow=',num2str(1.5418/(2*sin(parama(5)/2*pi/180)))])
    h=plot(xk,yf+i,'k');
    set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    % peak at 2theta=24
    ind=find((x<32).*(x>16));xk=x(ind);yk=y(ind);[ym,im]=max(yk);
    param=[0  ym 1 0.5 xk(im)];
    parama=fminsearch(@fctvp,param,option);
    yf=parama(1)+voigt(xk,parama(2:end));
    disp(['Lc=',num2str(0.89*1.5418/(parama(3)*2/180*pi*cos(parama(5)/2*pi/180))),'  d=',num2str(1.5418/(2*sin(parama(5)/2*pi/180)))])
    h=plot(xk,yf+i,'k');
    %%%%%%%%
    ind=find((x<60).*(x>36));xk=x(ind);yk=y(ind);[ym,im]=max(yk);
    set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    param=[0  30 ym 0.0];
    parama=fminsearch(@fctturbo,param,option);
    yf=parama(1)+fctturbo10s(xk,parama(2),parama(3),parama(4));a=1.42;da=a*tan(42/2*pi/180)*parama(4)/180*pi;
    disp(['10 : La=',num2str(parama(2)),'  a=',num2str(a+da)])
    h=plot(xk,yf+i,'k');
    set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
     % peak at 2theta=80    
    ind=find((x<83).*(x>70));xk=x(ind);yk=y(ind);[yma,im]=max(yk);ymi=min(yk);
    param=[ymi  parama(2) yma-ymi parama(4)];
    parama=fminsearch(@fctturbo2,param,option);
    yf=parama(1)+fctturbo11s(xk,parama(2),parama(3),parama(4));a=1.42;da=a*tan(78/2*pi/180)*parama(4)/180*pi;
    disp(['11 : La=',num2str(parama(2)),'  a=',num2str(a+da)])
    h=plot(xk,yf+i,'k');
xlabel('2\theta (�)','fontsize',14)
ylabel('Intensity (arbitrary units)','fontsize',14)
set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');       

ind=find((x<17).*(x>10));
a1=trapz(x(ind),y(ind));
ind=find((x<33).*(x>17));
a2=trapz(x(ind),y(ind));
disp(['Rapport des aires DCL / 001 : ',num2str(a1/a2)])
disp(' ') 

end
axis([10 100 0.98 3.5])
legend('1800�C-2�C/min','1000�C-2�C/min')
text(12,2.7,'DCL')
text(23,3.3,'001')
text(42,2.8,'10')
text(78,2.3,'11')
% legend('1000�C-2�C/min','1000�C-8�C/min','1800�C-2�C/min','1800�C-8�C/min')