function y=fctturbofano11s(x,La,dec11)
%all rights reserved P. Puech
A=2.3896*La.^0.4657-2.1058;
Gleft=42.4031./(La-1.4659).^0.9046;
q=-1.84;
Gright=38.0277./(La-1.9519).^0.8765;
xm=34.65./La-153.86./La.^2+579.80./La.^3+77.6463+0.0034+dec11;
G=5.74*6649.31./((La-57.36).^2+6649.31)+0.99;
n=0.6;
ng=1;
nd=0;
k=-102.76./La+3376.17./La.^2+0.12;
x0=xm-G/q;
Im=(1+(xm-x0)/(G*q))^2/(1+((xm-x0)/G)^2);
cte=0;
y=(x<xm).*((cte)+(1-cte)*((abs(ng)*exp(-log(2)*((x-xm)/Gleft).^2)+(1-abs(ng))*1./(1+((x-xm)/Gleft).^2))));
voigtd=(x>=xm).*((abs(nd)*exp(-log(2)*((x-xm)/Gright).^2)+(1-abs(nd))*1./(1+((x-xm)/Gright).^2)));
fano=((1+(2*xm-x-x0)/(G*q)).^2./(1+((2*xm-x-x0)/G).^2)+k*xm./x)/(Im+k);
y=y+(x>=xm).*((1-n)*(fano)+n*voigtd);
y=A*y+27.37./La+0.96-378.86./La.^2;

