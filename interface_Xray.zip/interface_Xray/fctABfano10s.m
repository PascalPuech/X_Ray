function y=fctABfano10s(La,dec10,x)
A=(abs(6.5618*La-0.3287.*La.^2)).^0.2733+10.63-298.43/La+1929.65./La.^2+50.62./La.^0.5;
%abs(param(1));%sqrt(0.792+0.00521*La);
Gleft=60.7684./La.^1.0025;%abs(param(2));%5.9/La;
q=-3;%param(3);%-100;
Gright=1.9276e+27./(La+587.0172).^9.6930+0.1159;
%xm=61.7540./(La.^2+153.93).^0.5434+42.4317+2.4546./La.^2-1.5913./La.^4+0.0022;
%xm=240.2059./(La+19.5230).^1.3368+42.4442+4.2025./La.^2+10.0215./La.^2;                                          
xm=156.36./(La+7.8211).^1.2642+42.4422+109.6193./La.^2-347.1591./La.^2+dec10;                
%param(4);%-4.467/La+42.34+CORR;
G=3.2+7.5334./La-0.1142./La.^2;%abs(param(5));%3.8;
n=min(max(0.09,0.0608+0.0036407*(1+1.5346*abs(La-108.26).^4.7966).^0.1460),1);
%min(max(0,abs(param(6))),1);%max(0,0.00872*La-0.00621);
ng=1;%min(max(0,abs(param(7))),1);
nd=min(max(0,215.7./La+34.03./La-0.18),1);%1;%min(max(0,abs(param(8))),1);
k=-0.4929-38.1529./La.^2-19.7069./La.^4;%param(9);         
x0=xm-G/q;
Im=(1+(xm-x0)/(G*q))^2/(1+((xm-x0)/G)^2);
cte=min(max(0,5.7890e+06./(La+436.4179).^10.3088),1);
y=(x<xm).*((cte)+(1-cte)*((abs(ng)*exp(-log(2)*((x-xm)/Gleft).^2)+(1-abs(ng))*1./(1+((x-xm)/Gleft).^2))));
voigtd=(x>=xm).*((abs(nd)*exp(-log(2)*((x-xm)/Gright).^2)+(1-abs(nd))*1./(1+((x-xm)/Gright).^2)));
fano=((1+(2*xm-x-x0)/(G*q)).^2./(1+((2*xm-x-x0)/G).^2)+k*xm./x)/(Im+k);
%y=y+(x>=xm).*((1-n)*(fano.*(fano>0))+n*(exp(-log(2)*((x-xm)/Gright).^2)));%gaussien en voigt
y=y+(x>=xm).*((1-n)*(fano.*(fano>0))+n*voigtd);%gaussien en voigt
y=A*y-0.2458/(La+703.12).^2.7758+0.9424+39.4318./La^2;

%yf=yf+prop*y;
%end
