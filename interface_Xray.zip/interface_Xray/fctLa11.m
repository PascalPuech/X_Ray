function fctLa11
global x y data xk yk vt
% with what (vt,vp,vb,vr)
for i=1:4
    switch(i)
        case 1
            vt(1)=get(data.turbo,'Value');
            val{1}=get(data.xturbo,'String');
        case 2
            vt(2)=get(data.pair,'Value');
            val{2}=get(data.xpair,'String');
        case(3)
            vt(3)=get(data.bernal,'Value');
            val{3}=get(data.xbernal,'String');
        case(4)
            vt(4)=get(data.rhombo,'Value');
            val{4}=get(data.xrhombo,'String');
    end
    if vt(i)==1
        if val{i}(1)=='%'
            vtv(i)=1;
        else
            vtv(i)=0.01*str2num(val{i});
        end
    else
        vtv(i)=0;
    end
end
vtv=vtv/sum(vtv);
% La
La=str2num(get(data.zLa11,'String'));

%initialisation
ind=find((x<90).*(x>70));
xk=x(ind);yk=y(ind);[ym,im]=max(yk);
if isempty(La)
    ind=find(yk>((ym-min(yk))/2+mean(yk)));
    fw=(xk(im)-xk(ind(1)))*2;
    La=0.89*1.5418/(fw*2/180*pi*cos(xk(im)/2*pi/180)) %en A
end
% L'c bernal + rhombo
if vt(3)==1
    Lpcb=str2num(get(data.zLpcb,'String'));
    if isempty(Lpcb)
        Lpcb=10.5;
    end
else
    Lpcb=0;
end
if vt(4)==1
    Lpcr=str2num(get(data.zLpcr,'String'));
    if isempty(Lpcr)
        Lpcr=10.5;
    end
else
    Lpcr=0;
end 
option=optimset('MaxFunEvals',100000,'MaxIter',100000,'TolX',1.e-8);
ino=find((xk<75).*(xk>70));
% param = [bg=0, height=ym, La, da=0, Lpcb, Lpcr, vtv(1:4) ]    ; vt is global
param=[mean(y),ym,La+0.5,0,Lpcb,Lpcr, vtv(1:4)];
param=fminsearch(@fctz11,param,option);
% graphic
mat=[xk];
yf=zeros(size(xk));
param(7:10)=abs(vt.*param(7:10))/sum(abs(vt.*param(7:10)));
if vt(1)==1
    ytmp=param(7)*fctturbo11s(xk,param(3),param(4));
    yf=yf+ytmp;
    ytmp=param(2)*ytmp+param(1);
    mat=[mat,ytmp];
end
if vt(2)==1
    ytmp=param(8)*fctABfano11s(param(3),param(4),xk);
    yf=yf+ytmp;
    ytmp=param(2)*ytmp+param(1);
    mat=[mat,ytmp];
end
if vt(3)==1
    ytmp=param(9)*fctbernal11s(param(3),param(5),xk,param(4));
    yf=yf+ytmp;
    ytmp=param(2)*ytmp+param(1);
    mat=[mat,ytmp];
end
if vt(4)==1
    ytmp=param(10)*fabc11s(param(3),param(6),xk,param(4));
    yf=yf+ytmp;
    ytmp=param(2)*ytmp+param(1);
    mat=[mat,ytmp];
end
yf=param(2)*yf+param(1);
mat=[mat,yf];
if data.c11>1
    set(data.h11,'XData',[],'YData',[])
end
hold on
h11=plot(xk,mat(:,2:end));
data.h11=h11;
data.z11mat=mat;

%interface
if vt(1)==1, set(data.xturbo,'String',num2str(100*param(7))); end
if vt(2)==1, set(data.xpair,'String',num2str(100*param(8))); end
if vt(3)==1, set(data.xbernal,'String',num2str(100*param(9))); end
if vt(4)==1, set(data.xrhombo,'String',num2str(100*param(10))); end
set(data.zLa11,'String',num2str(param(3)));
a=1.42;da=a*tan(42/2*pi/180)*param(4)/180*pi;
set(data.za11,'String',num2str(a+da));
if vt(3)==1, set(data.zLpcb,'String',num2str(min(max([10.5 param(5)]),1000))); end
if vt(4)==1, set(data.zLpcr,'String',num2str(param(6))); end


