#include "mex.h"
#include "string.h"
#include "stdio.h"
#define SEPCHARS "@ ;\"\t\"\n"

void analyse(char *nom, int *npt, int *ncol){
FILE *pf;
char message[64];
char ligne[256];
char *mot;
int i,test;
pf=fopen(nom,"r");
if (pf==NULL) {sprintf(message,"Le fichier '%s' n'existe pas\n",nom);mexErrMsgTxt(message);}
npt[0]=0;ncol[0]=0;test=0;
while ((fgets(ligne,256,pf)!=NULL)&&(test==0)){
	if((strlen(ligne)!=0)&&(strlen(ligne)!=1)&&(ligne[0]!='@')&&(ligne[0]!='#')&&(ligne[0]!='%')&&(ligne[0]!='"')&&(ligne[0]!='_')&&(ligne[0]!=';')) {
		mot=strtok(ligne,SEPCHARS);
		mot=strtok(NULL,SEPCHARS);
		if (mot==NULL) {fgets(ligne,256,pf);mot=strtok(ligne,SEPCHARS);}
		i=0;
		if (mot==NULL) {if(fgets(ligne,256,pf)!=NULL){mot=strtok(ligne,SEPCHARS);}}
		while (mot!=NULL){mot=strtok(NULL,SEPCHARS);i++;}
		if(i>ncol[0]){ncol[0]=i;}
		npt[0]++;}
	else{
	    if(npt[0]!=0){
            if (strstr(nom,"ms0")!=NULL){
                test++;}}}}
fclose(pf);
}

void lecture(char *nom, double *x, double *y,int nbpt){
FILE *pf;
char ligne[256];
char *mot,*test;
int i,npt;
pf=fopen(nom,"r");
npt=0;
while ((fgets(ligne,256,pf)!=NULL)&&(npt<nbpt)){
	if((strlen(ligne)!=0)&&(strlen(ligne)!=1)&&(ligne[0]!='@')&&(ligne[0]!='#')&&(ligne[0]!='%')&&(ligne[0]!='"')&&(ligne[0]!='_')&&(ligne[0]!=';')) {
		mot=strtok(ligne,SEPCHARS);
		x[npt]=atof(mot);
		mot=strtok(NULL,SEPCHARS);
		i=0;
		if (mot==NULL) {if(fgets(ligne,256,pf)!=NULL){mot=strtok(ligne,SEPCHARS);}}
		while (mot!=NULL){
		    y[npt+i*nbpt]=atof(mot);
		    i++;
		    mot=strtok(NULL,SEPCHARS);}
		npt++;}}
fclose(pf);
return;
}

void inverse(double *x,double *y,int *npt,int *ncol){
int i,j;
double tmp;
for (i=0;i<(npt[0]/2);i++){
	tmp=x[i];
	x[i]=x[npt[0]-1-i];
	x[npt[0]-1-i]=tmp;
	for(j=0;j<ncol[0];j++){
		tmp=y[i+j*npt[0]];
		y[i+j*npt[0]]=y[npt[0]-1-i+j*npt[0]];
		y[npt[0]-1-i+j*npt[0]]=tmp;}}
}

void nettoie(double *y,int *npt, int *ncol, int *larg, double *ecart){
int i,j,k;
double pente,pentemax,pentemin,a,b;
double max,min;
int imax,imin;
for (k=0;k<ncol[0];k++){
    for (i=larg[0];i<npt[0]-1-larg[0];i++) {
        imax=-1;max=y[i-1+k*npt[0]];
        for(j=-larg[0];j<=larg[0];j++){if(max<y[i+j+k*npt[0]]){max=y[i+j+k*npt[0]];imax=j;}}
        if(imax==0){
            pentemax=(y[i+k*npt[0]]-y[i-1+k*npt[0]]);
            pentemin=(y[i+k*npt[0]]-y[i-1+k*npt[0]]);
            for(j=-larg[0]+1;j<=larg[0]-1;j++){
                pente=y[i+j+k*npt[0]]-y[i+j-1+k*npt[0]];
                if(pentemax<pente){pentemax=pente;}
                if(pentemin>pente){pentemin=pente;}}
            if((pentemin*pentemax)<(-(ecart[0]*ecart[0]))){
                b=0.5*(y[i-larg[0]+k*npt[0]]+y[i+larg[0]+k*npt[0]]);
                a=(y[i+larg[0]+k*npt[0]]-b)/(double)(larg[0]);
                for(j=-larg[0]+1;j<=larg[0]-1;j++){
                    y[i+j+k*npt[0]]=a*j+b;}}}}
    for (i=larg[0];i<npt[0]-1-larg[0];i++) {
        imin=-1;min=y[i-1+k*npt[0]];
        for(j=-larg[0];j<=larg[0];j++){if(min>y[i+j+k*npt[0]]){min=y[i+j+k*npt[0]];imin=j;}}
        if(imin==0){
            pentemax=(y[i+k*npt[0]]-y[i-1+k*npt[0]]);
            pentemin=(y[i+k*npt[0]]-y[i-1+k*npt[0]]);
            for(j=-larg[0]+1;j<=larg[0]-1;j++){
                pente=y[i+j+k*npt[0]]-y[i+j-1+k*npt[0]];
                if(pentemax<pente){pentemax=pente;}
                if(pentemin>pente){pentemin=pente;}}
            if((pentemin*pentemax)<(-(ecart[0]*ecart[0]))){
                b=0.5*(y[i-larg[0]+k*npt[0]]+y[i+larg[0]+k*npt[0]]);
                a=(y[i+larg[0]+k*npt[0]]-b)/(double)(larg[0]);
                for(j=-larg[0]+1;j<=larg[0]-1;j++){
                    y[i+j+k*npt[0]]=a*j+b;}}}}}
}

void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[]){
int n,m,npt,ncol;
char *nom;
double net,ecart;
int inet;
double *x,*y;
if ((nrhs<1)|(nrhs>3)) {
    mexErrMsgTxt("\nFournir au moins un argument (nom)\npuis pour �liminer les pics un entier compris entre 1 et 10 puis le saut\n[x,y]=lecture('nom'); ou [x,y]=lecture('nom',3); ou [x,y]=lecture('nom',3,50);\n");}
if (nlhs!=2)  {mexErrMsgTxt("2 arguments demand�s en retour [x,y]=lecture('nom');");}
if (!mxIsChar(prhs[0])) {mexErrMsgTxt("Donnez un nom : [x,y]=lecture('nom');");}
m=mxGetM(prhs[0]);
n=mxGetN(prhs[0]);
if(!((m==1)|(n==1))){mexErrMsgTxt("Vous avez fourni un tableau");}
nom=mxCalloc(m*n+1,sizeof(char));
mxGetString(prhs[0],nom,m*n+1);
analyse(nom,&npt,&ncol);
plhs[0]=mxCreateDoubleMatrix(npt,1,mxREAL);
plhs[1]=mxCreateDoubleMatrix(npt,ncol,mxREAL);
x=mxGetPr(plhs[0]);
y=mxGetPr(plhs[1]);
lecture(nom,x,y,npt);
if(x[1]<x[0]) {inverse(x,y,&npt,&ncol);}
if(nrhs!=1) {
    net = mxGetScalar(prhs[1]);
    inet=(int)(net);
    if (nrhs==3) {ecart=mxGetScalar(prhs[2]);} else{ecart=50;}
    if((inet>0)&&(inet<10)){
        nettoie(y,&npt,&ncol,&inet,&ecart);
        }}
}



