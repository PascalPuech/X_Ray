clear all, close all, clc
x=40:0.01:50;
y = fctbernal10s(500,30,0,0,x);%fctbernal10s(La,Lc,dec10,dec101,x)
plot(x,y)