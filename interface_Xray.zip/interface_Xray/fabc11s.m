function [y] = fabc11s(La,Lc,x,param)
% limit� � 82
param=[7765.21        -63.17         -0.36       4377.83          0.00         96.11  ...
    1.15       5661.70        142.23        100.79          0.54          1.19        202.74 ...
    23.14        -18.02        100.64        211.12         42.72]/100;
w=param(1)+param(2)./La;
G1=param(3)+param(4)./(La+abs(param(5))).^param(6);
G2=param(7)+param(8)./(La+abs(param(9))).^param(10);
n=param(11)*La+param(12)./La+param(13);
n=min(max(0,n),1);
int1=param(14)*(La+param(15)).^param(16);

y=(x<w).*((abs(n)*exp(-log(2)*((x-w)/G1).^2)+(1-abs(n))*1./(1+((x-w)/G1).^2)));
y=y+(x>=w).*((abs(n)*exp(-log(2)*((x-w)/G2).^2)+(1-abs(n))*1./(1+((x-w)/G2).^2)));
y=int1*y+param(17)+param(18)*(x-77.8);

end