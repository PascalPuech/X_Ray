function err=fctal(c)
global x y
q=sin(x/360*pi);
yf=zeros(size(x));
for ii=1:2:5
    yf=yf+abs(c(ii+1))*exp(-c(ii)*q.^2);
end
yf=yf+c(end);
err=sum(((yf-y).^2.*(yf<=y)+(yf-y).^2.*(yf>y)*10000));
