function y=fctABfano11s(La,dec11,x)
%A=(9.6856e+10*La+9.2067e+12).^0.1772-200.4535;%(-13952*La+1716.6.*La.^2).^0.2049;
A=(76605337525.20*La+11722841071674.42).^0.1885-272.19-1.24*(La+247.65).^0.5;
Gleft=79.9297./(La+14.6699).^1.0262;%28.0287./(La-2.7663).^0.8505;
q=2;%-3;
Gright=1.4834e+04./La.^2.5391+4.2110./La.^0.5;%78.0526./(La-0.3623).^1.0408;
%xm=param(1)./(La.^2+param(2)).^param(3)+param(4)-param(5)./La.^2+param(6)./La.^4;
xm=32.9978./(La.^2+9.4649e+03).^0.4973+77.6359+408.4829./La.^2+1.3442e+05./La.^4+dec11;
G=2.5;%217.0834./La.^0.8479;
n=1;%min(max(0,param(7)),1);%abs(3.5609./La.^0.8957+0.5594)),1);
ng=min(max(0,0.9024-4.0516e-04*La),1);
nd=0;%min(max(0,abs(param(9))),1);
k=0.015+0.0008*La;%-3.9059./La.^0.1955+1.2136;
x0=xm-G/q;
Im=(1+(xm-x0)/(G*q))^2/(1+((xm-x0)/G)^2);
%y=(x<xm).*exp(-log(2)*((x-xm)/Gleft).^2);%x<xm, gaussien � transformer en voigt
cte=0;%param(11);%min(max(0,abs(6.5516./La.^1.3406+0.0551)),1);
y=(x<xm).*((cte)+(1-cte)*((abs(ng)*exp(-log(2)*((x-xm)/Gleft).^2)+(1-abs(ng))*1./(1+((x-xm)/Gleft).^2))));
voigtd=(x>=xm).*((abs(nd)*exp(-log(2)*((x-xm)/Gright).^2)+(1-abs(nd))*1./(1+((x-xm)/Gright).^2)));
fano=((1+(2*xm-x-x0)/(G*q)).^2./(1+((2*xm-x-x0)/G).^2)+k*xm./x)/(Im+k);
%y=y+(x>=xm).*((1-n)*(fano.*(fano>0))+n*(exp(-log(2)*((x-xm)/Gright).^2)));%gaussien en voigt
y=y+(x>=xm).*((1-n)*(fano.*(fano>0))+n*voigtd);%gaussien en voigt
y=abs(A*y-4.80/(La+37873.27).^169.85+0.64+525.35./La^2);

%yf=yf+prop*y;
%end