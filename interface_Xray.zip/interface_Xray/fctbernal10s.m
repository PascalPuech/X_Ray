function [ye] = fctbernal10s(La,Lc,dec10,dec101,x)
%ici param n'est pas affect�, � mettre sur une variable ...
%param=[ 4254.96       -942.94      -1553.74       5800.24       4118.99        146.41         11.93       -113.33        134.07        -50.88      -1134.20     ...
%    1530.29       4473.31          7.57     143283.76     180011.11 ...
%     206526.61      10173.80       7526.66         93.20       5563.64      19512.29      11762.27       -224.13       -193.13      -2505.83       3219.72          0.015332]/100;
param=[4255.03-10.98       -856.72      -1609.11       5512.93       4178.28        149.35         11.41        -38.25        150.74         38.81 ...
    -3139.32       1905.18       4473.35-7.98          0.1900    6206531.77     192140.51 ...
     222901.47      14271.39    -838309.56     724723.90       5640.69      18045.44   ...
     705032.90 1940856009.94       -150.12       -808.96     -37422.92          4.248e-05]/100;
Lc=min(max([10.5 Lc]),1000);
wm=param(1)+(param(2)./La).*(1+param(3)./Lc)+dec10;
Gd=param(4)./La.*(1+param(10)./Lc);
Gg=(param(5)./La).*(1+param(6)./Lc);
nd=1;
ng=1;
cte=param(9)+param(11)./La;
intensite=La*param(7)*(1+param(8)./Lc)*(1+param(12)./La);

ng=min(max(0,abs(ng)),1);
nd=min(max(0,abs(nd)),1);

y=(x<wm).*((abs(ng)*exp(-log(2)*((x-wm)/Gg).^2)+(1-abs(ng))*1./(1+((x-wm)/Gg).^2)));
y=y+(x>=wm).*((abs(nd)*exp(-log(2)*((x-wm)/Gd).^2)+(1-abs(nd))*1./(1+((x-wm)/Gd).^2)));
ye=intensite*y+cte;

param(1:16)=param(13:end);

wm=param(1)+(param(2)./La).*(1+param(3)./Lc)+param(13)./Lc+param(14)./Lc.^2+param(15)./Lc.^3+dec101;
Gd=sqrt(abs(param(4)./La.^2+param(10)./Lc.^2+param(11)./Lc.^4));
Gg=sqrt(abs(param(5)./La.^2+param(6)./Lc.^2+param(7)./Lc.^4));
nd=1;
ng=1;

intensite=(param(9)/(Gd+Gg))*(1+param(16)*(param(8)+sqrt(Lc))./Lc);

ng=min(max(0,abs(ng)),1);
nd=min(max(0,abs(nd)),1);

y=(x<wm).*((abs(ng)*exp(-log(2)*((x-wm)/Gg).^2)+(1-abs(ng))*1./(1+((x-wm)/Gg).^2)));
y=y+(x>=wm).*((abs(nd)*exp(-log(2)*((x-wm)/Gd).^2)+(1-abs(nd))*1./(1+((x-wm)/Gd).^2)));
y=intensite*y;
ye=ye+y;
ye=ye.*(Lc>1).*(La>10);

end