function yf=voigt(x,param)
frac=min(1,abs(param(3))); % fixe frac � 1 pour gaussien et � 0 pour lorentzien, donc juste �crire par exmeple apr�s cette ligne frac=1;
intensity=abs(param(1));
gam=abs(param(2));
y=zeros(size(x));
lo=gam^2./((x-param(4)).^2+gam^2);
ga=exp(-log(2)*(x-abs(param(4))).^2/(gam^2));
yf=intensity*(frac*ga+(1-frac)*lo);
