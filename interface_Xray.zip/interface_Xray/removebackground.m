function removebackground
global x y data
option=optimset('MaxFunEvals',100000,'MaxIter',100000,'TolX',1.e-8);
c=fminsearch(@fctal,[1.13       1366.10        240.85      31036.69         30.80      25360.05   30.80      20360.05 0.33],option);
q=sin(x/360*pi);
yf=zeros(size(x));
for ii=1:2:5
    yf=yf+abs(c(ii+1))*exp(-c(ii)*q.^2);
end
yf=yf+c(end);
y=(y-yf);
set(data.hxy,'YData',y);


