function readfile
global x y data
[fname, pname] = uigetfile('*.txt'); 
data.fname=fname;data.pname=pname;
nom = fullfile(pname, fname); 
[x,y]=lectura(nom);
set(data.nom,'String',nom);
cla
hxy=plot(x,y,'.','LineWidth',0.3);
set(hxy,'Color',[0.7 0.7 0.7]);
data.hxy=hxy;
hold on


set(data.xfrom,'String','from');
set(data.xto,'String','to');
set(data.zLpcb,'String','to be calculated');
set(data.xrhombo,'String','%')
set(data.zLpcr,'String','to be calculated');
set(data.zLc,'String','to be calculated');
set(data.zc,'String','to be calculated');
set(data.zLa10,'String','to be calculated');
set(data.za10,'String','to be calculated');
set(data.zLa11,'String','to be calculated');
set(data.za11,'String','to be calculated');
data.c10=0;
data.c11=0;


